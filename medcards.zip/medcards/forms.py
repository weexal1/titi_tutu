from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed, FileRequired
from wtforms import StringField, PasswordField, SubmitField, SelectField, TextAreaField, DateField, DateTimeField, IntegerField
from wtforms.validators import DataRequired, Email, Length, Optional
from datetime import datetime

class LoginForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired()])
    password = PasswordField('Пароль', validators=[DataRequired()])
    submit = SubmitField('Войти')

class RegistrationForm(FlaskForm):
    username = StringField('Логин', validators=[DataRequired(), Length(min=3, max=80)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Пароль', validators=[DataRequired(), Length(min=6)])
    role = SelectField('Роль', choices=[
        ('patient', 'Пациент'),
        ('doctor', 'Врач'),
        ('nurse', 'Медсестра'),
        ('admin', 'Администратор')
    ], validators=[DataRequired()])
    submit = SubmitField('Зарегистрироваться')

class PatientForm(FlaskForm):
    full_name = StringField('ФИО', validators=[DataRequired()])
    birth_date = DateField('Дата рождения', format='%Y-%m-%d', validators=[DataRequired()])
    address = TextAreaField('Адрес', validators=[Optional()])
    phone = StringField('Телефон', validators=[Optional()])
    email = StringField('Email', validators=[Optional(), Email()])
    passport_data = StringField('Паспортные данные', validators=[Optional()])
    insurance_number = StringField('Страховой номер', validators=[Optional()])
    submit = SubmitField('Сохранить')

class MedicalRecordForm(FlaskForm):
    blood_type = SelectField('Группа крови', choices=[
        ('', 'Не указана'),
        ('I+', 'I+'), ('I-', 'I-'),
        ('II+', 'II+'), ('II-', 'II-'), 
        ('III+', 'III+'), ('III-', 'III-'),
        ('IV+', 'IV+'), ('IV-', 'IV-')
    ], validators=[Optional()])
    allergies = TextAreaField('Аллергии', validators=[Optional()])
    chronic_diseases = TextAreaField('Хронические заболевания', validators=[Optional()])
    current_medications = TextAreaField('Текущие лекарства', validators=[Optional()])
    family_history = TextAreaField('Семейный анамнез', validators=[Optional()])
    submit = SubmitField('Сохранить')

class MedicalNoteForm(FlaskForm):
    visit_date = DateTimeField('Дата визита', format='%Y-%m-%d %H:%M', default=datetime.now, validators=[DataRequired()])
    symptoms = TextAreaField('Жалобы и симптомы', validators=[Optional()])
    diagnosis = TextAreaField('Диагноз', validators=[DataRequired()])
    treatment = TextAreaField('Лечение', validators=[Optional()])
    prescriptions = TextAreaField('Назначения', validators=[Optional()])
    recommendations = TextAreaField('Рекомендации', validators=[Optional()])
    notes = TextAreaField('Примечания', validators=[Optional()])
    submit = SubmitField('Сохранить запись')

class AppointmentForm(FlaskForm):
    patient_id = SelectField('Пациент', coerce=int, validators=[DataRequired()])
    doctor_id = SelectField('Врач', coerce=int, validators=[DataRequired()])
    appointment_date = DateTimeField('Дата и время приёма', format='%Y-%m-%d %H:%M', validators=[DataRequired()])
    reason = TextAreaField('Причина обращения', validators=[Optional()])
    duration = IntegerField('Длительность (минут)', default=30, validators=[Optional()])
    submit = SubmitField('Записать')

class DocumentForm(FlaskForm):
    document = FileField('Файл', validators=[
        FileRequired(),
        FileAllowed(['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx'], 
                   'Разрешены: PDF, JPG, PNG, DOC, XLS')
    ])
    description = TextAreaField('Описание', validators=[Optional()])
    submit = SubmitField('Загрузить')

class SearchForm(FlaskForm):
    search_type = SelectField('Искать по', choices=[
        ('patient_name', 'ФИО пациента'),
        ('diagnosis', 'Диагнозу'),
        ('doctor', 'Врачу'),
        ('date', 'Дате визита')
    ], validators=[DataRequired()])
    query = StringField('Запрос', validators=[DataRequired()])
    submit = SubmitField('Найти')