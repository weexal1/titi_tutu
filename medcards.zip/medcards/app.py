from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, date, timedelta
import enum
import os
import uuid
from functools import wraps

app = Flask(__name__)
app.config['SECRET_KEY'] = 'medical-secret-key-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///medical.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

class UserRole(enum.Enum):
    PATIENT = 'patient'
    DOCTOR = 'doctor'
    NURSE = 'nurse'
    ADMIN = 'admin'

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    role = db.Column(db.Enum(UserRole), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    is_active = db.Column(db.Boolean, default=True)
    
    patient_profile = db.relationship('Patient', backref='user', uselist=False, cascade='all, delete-orphan')
    doctor_profile = db.relationship('Doctor', backref='user', uselist=False, cascade='all, delete-orphan')

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    full_name = db.Column(db.String(200), nullable=False)
    birth_date = db.Column(db.Date, nullable=False)
    address = db.Column(db.Text)
    phone = db.Column(db.String(20))
    email = db.Column(db.String(120))
    passport_data = db.Column(db.String(100))
    insurance_number = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    medical_record = db.relationship('MedicalRecord', backref='patient', uselist=False, cascade='all, delete-orphan')
    appointments = db.relationship('Appointment', backref='patient', cascade='all, delete-orphan')

class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    full_name = db.Column(db.String(200), nullable=False)
    specialization = db.Column(db.String(100), nullable=False)
    license_number = db.Column(db.String(50))
    department = db.Column(db.String(100))
    office_number = db.Column(db.String(20))
    phone = db.Column(db.String(20))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    appointments = db.relationship('Appointment', backref='doctor', cascade='all, delete-orphan')
    medical_notes = db.relationship('MedicalNote', backref='doctor', cascade='all, delete-orphan')

class MedicalRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    record_number = db.Column(db.String(50), unique=True)
    blood_type = db.Column(db.String(5))
    allergies = db.Column(db.Text)
    chronic_diseases = db.Column(db.Text)
    current_medications = db.Column(db.Text)
    family_history = db.Column(db.Text)
    last_visit = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    notes = db.relationship('MedicalNote', backref='medical_record', cascade='all, delete-orphan')
    documents = db.relationship('Document', backref='medical_record', cascade='all, delete-orphan')

class MedicalNote(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    record_id = db.Column(db.Integer, db.ForeignKey('medical_record.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    visit_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    symptoms = db.Column(db.Text)
    diagnosis = db.Column(db.Text, nullable=False)
    treatment = db.Column(db.Text)
    prescriptions = db.Column(db.Text)
    recommendations = db.Column(db.Text)
    notes = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    appointment_date = db.Column(db.DateTime, nullable=False)
    status = db.Column(db.String(20), default='scheduled')
    reason = db.Column(db.Text)
    duration = db.Column(db.Integer, default=30)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Document(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    record_id = db.Column(db.Integer, db.ForeignKey('medical_record.id'), nullable=False)
    filename = db.Column(db.String(255), nullable=False)
    original_filename = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500), nullable=False)
    file_type = db.Column(db.String(50))
    file_size = db.Column(db.Integer)
    description = db.Column(db.Text)
    uploaded_by = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    uploader = db.relationship('User', foreign_keys=[uploaded_by])

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

def role_required(roles):
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if current_user.role not in roles:
                flash('Доступ запрещен. Недостаточно прав.', 'error')
                return redirect(url_for('dashboard'))
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password, password):
            if not user.is_active:
                flash('Аккаунт заблокирован', 'error')
                return render_template('login.html')
                
            login_user(user)
            flash('Успешный вход!', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Неверный логин или пароль', 'error')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        try:
            username = request.form['username']
            password = request.form['password']
            role = request.form['role']
            
            if len(username) < 3:
                flash('Логин должен быть не менее 3 символов', 'error')
                return render_template('register.html')
                
            if len(password) < 6:
                flash('Пароль должен быть не менее 6 символов', 'error')
                return render_template('register.html')
            
            if User.query.filter_by(username=username).first():
                flash('Этот логин уже занят', 'error')
                return render_template('register.html')
            
            user = User(
                username=username,
                email=f"{username}@hospital.ru",
                password=generate_password_hash(password),
                role=UserRole(role)
            )
            db.session.add(user)
            db.session.commit()
            
            if role == 'patient':
                patient = Patient(
                    user_id=user.id,
                    full_name=username,
                    birth_date=date.today(),
                    phone='Не указан',
                    email=f"{username}@hospital.ru",
                    address='Не указан'
                )
                db.session.add(patient)
                db.session.commit()
                
                medical_record = MedicalRecord(patient_id=patient.id)
                db.session.add(medical_record)
                db.session.commit()
            
            elif role == 'doctor':
                doctor = Doctor(
                    user_id=user.id,
                    full_name=username,
                    specialization='Терапевт',
                    license_number='',
                    department='',
                    office_number='',
                    phone=''
                )
                db.session.add(doctor)
                db.session.commit()
            
            flash('✅ Регистрация успешна! Можете войти.', 'success')
            return redirect(url_for('login'))
            
        except Exception as e:
            db.session.rollback()
            flash(f'Ошибка при регистрации: {str(e)}', 'error')
            return render_template('register.html')
    
    return render_template('register.html')

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.route('/my-profile')
@login_required
def my_profile():
    if current_user.role == UserRole.PATIENT:
        return redirect(url_for('patient_dashboard'))
    elif current_user.role == UserRole.DOCTOR:
        return redirect(url_for('doctor_dashboard'))
    elif current_user.role == UserRole.NURSE:
        return redirect(url_for('nurse_dashboard'))
    elif current_user.role == UserRole.ADMIN:
        return redirect(url_for('admin_dashboard'))

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

@app.route('/medical-records')
@login_required
def medical_records():
    if current_user.role not in [UserRole.DOCTOR, UserRole.NURSE, UserRole.ADMIN]:
        flash('Доступ запрещен', 'error')
        return redirect(url_for('dashboard'))
    
    query = request.args.get('q', '')
    search_type = request.args.get('type', 'patient_name')
    
    records_query = MedicalRecord.query.join(Patient)
    
    if query:
        if search_type == 'patient_name':
            records_query = records_query.filter(Patient.full_name.ilike(f'%{query}%'))
        elif search_type == 'diagnosis':
            records_query = records_query.join(MedicalNote).filter(MedicalNote.diagnosis.ilike(f'%{query}%'))
    
    records = records_query.all()
    return render_template('medical_records.html', records=records)

@app.route('/medical-record/<int:record_id>')
@login_required
def view_medical_record(record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    
    if current_user.role == UserRole.PATIENT:
        if not current_user.patient_profile or current_user.patient_profile.id != record.patient_id:
            flash('Доступ запрещен', 'error')
            return redirect(url_for('dashboard'))
    
    return render_template('view_medical_record.html', record=record)

@app.route('/medical-record/<int:record_id>/edit', methods=['GET', 'POST'])
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN])
def edit_medical_record(record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    
    if request.method == 'POST':
        record.blood_type = request.form.get('blood_type')
        record.allergies = request.form.get('allergies')
        record.chronic_diseases = request.form.get('chronic_diseases')
        record.current_medications = request.form.get('current_medications')
        record.family_history = request.form.get('family_history')
        record.updated_at = datetime.utcnow()
        
        db.session.commit()
        flash('Медицинская карта обновлена', 'success')
        return redirect(url_for('view_medical_record', record_id=record.id))
    
    return render_template('edit_medical_record.html', record=record)

@app.route('/medical-record/<int:record_id>/add-note', methods=['GET', 'POST'])
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN])
def add_medical_note(record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    
    if current_user.role == UserRole.DOCTOR and not current_user.doctor_profile:
        flash('Профиль врача не найден', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        visit_date = datetime.fromisoformat(request.form['visit_date'])
        
        note = MedicalNote(
            record_id=record.id,
            doctor_id=current_user.doctor_profile.id if current_user.role == UserRole.DOCTOR else 1,
            visit_date=visit_date,
            symptoms=request.form.get('symptoms'),
            diagnosis=request.form['diagnosis'],
            treatment=request.form.get('treatment'),
            prescriptions=request.form.get('prescriptions'),
            recommendations=request.form.get('recommendations'),
            notes=request.form.get('notes')
        )
        
        record.last_visit = visit_date
        record.updated_at = datetime.utcnow()
        
        db.session.add(note)
        db.session.commit()
        
        flash('Медицинская запись добавлена', 'success')
        return redirect(url_for('view_medical_record', record_id=record.id))
    
    return render_template('add_medical_note.html', record=record)

@app.route('/medical-record/<int:record_id>/upload', methods=['GET', 'POST'])
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN, UserRole.NURSE])
def upload_document(record_id):
    record = MedicalRecord.query.get_or_404(record_id)
    
    if request.method == 'POST':
        file = request.files['document']
        if file and file.filename:
            filename = secure_filename(file.filename)
            unique_filename = f"{uuid.uuid4()}_{filename}"
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(file_path)
            
            document = Document(
                patient_id=record.patient_id,
                record_id=record.id,
                filename=unique_filename,
                original_filename=filename,
                file_path=file_path,
                file_type=filename.rsplit('.', 1)[1].lower() if '.' in filename else '',
                file_size=os.path.getsize(file_path),
                description=request.form.get('description'),
                uploaded_by=current_user.id
            )
            
            db.session.add(document)
            db.session.commit()
            
            flash('✅ Файл успешно загружен', 'success')
            return redirect(url_for('view_medical_record', record_id=record.id))
        else:
            flash('❌ Файл не выбран', 'error')
    
    return render_template('upload_document.html', record=record)

@app.route('/download/<filename>')
@login_required
def download_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.route('/patient/dashboard')
@login_required
@role_required([UserRole.PATIENT])
def patient_dashboard():
    patient = current_user.patient_profile
    if not patient:
        flash('Профиль пациента не найден', 'error')
        return redirect(url_for('dashboard'))
    
    upcoming_appointments = Appointment.query.filter_by(
        patient_id=patient.id, 
        status='scheduled'
    ).filter(Appointment.appointment_date >= datetime.utcnow()).order_by(Appointment.appointment_date).limit(5).all()
    
    if patient.medical_record:
        recent_notes = MedicalNote.query.filter_by(
            record_id=patient.medical_record.id
        ).order_by(MedicalNote.visit_date.desc()).limit(5).all()
    else:
        recent_notes = []
    
    return render_template('patient_dashboard.html',
                         patient=patient,
                         upcoming_appointments=upcoming_appointments,
                         recent_notes=recent_notes)

@app.route('/doctor/dashboard')
@login_required
@role_required([UserRole.DOCTOR])
def doctor_dashboard():
    doctor = current_user.doctor_profile
    if not doctor:
        flash('Профиль врача не найден', 'error')
        return redirect(url_for('dashboard'))
    
    today = datetime.utcnow().date()
    today_appointments = Appointment.query.filter_by(
        doctor_id=doctor.id, 
        status='scheduled'
    ).filter(db.func.date(Appointment.appointment_date) == today).order_by(Appointment.appointment_date).all()
    
    total_patients = db.session.query(db.func.count(db.distinct(Appointment.patient_id))).filter_by(doctor_id=doctor.id).scalar()
    total_appointments = Appointment.query.filter_by(doctor_id=doctor.id).count()
    recent_notes = MedicalNote.query.filter_by(doctor_id=doctor.id).order_by(MedicalNote.visit_date.desc()).limit(5).all()
    
    return render_template('doctor_dashboard.html',
                         doctor=doctor,
                         today_appointments=today_appointments,
                         total_patients=total_patients,
                         total_appointments=total_appointments,
                         recent_notes=recent_notes)

@app.route('/nurse/dashboard')
@login_required
@role_required([UserRole.NURSE])
def nurse_dashboard():
    today = datetime.utcnow().date()
    today_appointments = Appointment.query.filter(
        Appointment.status == 'scheduled'
    ).filter(db.func.date(Appointment.appointment_date) == today).order_by(Appointment.appointment_date).all()
    
    patients_without_data = Patient.query.filter(
        db.or_(
            Patient.phone.is_(None),
            Patient.address.is_(None),
            Patient.email.is_(None)
        )
    ).limit(10).all()
    
    return render_template('nurse_dashboard.html',
                         today_appointments=today_appointments,
                         patients_without_data=patients_without_data)

@app.route('/admin/dashboard')
@login_required
@role_required([UserRole.ADMIN])
def admin_dashboard():
    total_patients = Patient.query.count()
    total_doctors = Doctor.query.count()
    total_appointments = Appointment.query.count()
    total_medical_notes = MedicalNote.query.count()
    
    recent_users = User.query.order_by(User.created_at.desc()).limit(10).all()
    
    appointment_stats = db.session.query(
        Appointment.status,
        db.func.count(Appointment.id)
    ).group_by(Appointment.status).all()
    
    return render_template('admin_dashboard.html',
                         total_patients=total_patients,
                         total_doctors=total_doctors,
                         total_appointments=total_appointments,
                         total_medical_notes=total_medical_notes,
                         recent_users=recent_users,
                         appointment_stats=appointment_stats)

@app.route('/admin/users')
@login_required
@role_required([UserRole.ADMIN])
def admin_users():
    users = User.query.all()
    return render_template('admin_users.html', users=users)

@app.route('/admin/user/<int:user_id>/toggle-active', methods=['POST'])
@login_required
@role_required([UserRole.ADMIN])
def toggle_user_active(user_id):
    user = User.query.get_or_404(user_id)
    user.is_active = not user.is_active
    db.session.commit()
    
    status = "активен" if user.is_active else "заблокирован"
    flash(f'Пользователь {user.username} теперь {status}', 'success')
    return redirect(url_for('admin_users'))

@app.route('/patients')
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN, UserRole.NURSE])
def patients_list():
    search_query = request.args.get('search', '')
    
    if search_query:
        patients = Patient.query.filter(Patient.full_name.ilike(f'%{search_query}%')).all()
    else:
        patients = Patient.query.all()
    
    return render_template('patients_list.html', patients=patients, search_query=search_query)

@app.route('/patient/<int:patient_id>')
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN, UserRole.NURSE])
def patient_detail(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    return render_template('patient_detail.html', patient=patient)

@app.route('/appointments')
@login_required
def appointments_list():
    if current_user.role == UserRole.PATIENT:
        patient = current_user.patient_profile
        if not patient:
            flash('Профиль пациента не найден', 'error')
            return redirect(url_for('dashboard'))
        appointments = Appointment.query.filter_by(patient_id=patient.id).order_by(Appointment.appointment_date.desc()).all()
    elif current_user.role == UserRole.DOCTOR:
        doctor = current_user.doctor_profile
        if not doctor:
            flash('Профиль врача не найден', 'error')
            return redirect(url_for('dashboard'))
        appointments = Appointment.query.filter_by(doctor_id=doctor.id).order_by(Appointment.appointment_date.desc()).all()
    else:
        appointments = Appointment.query.order_by(Appointment.appointment_date.desc()).all()
    
    return render_template('appointments_list.html', appointments=appointments)

@app.route('/appointment/create', methods=['GET', 'POST'])
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN, UserRole.NURSE])
def create_appointment():
    if request.method == 'POST':
        appointment_date = datetime.fromisoformat(request.form['appointment_date'])
        
        appointment = Appointment(
            patient_id=request.form['patient_id'],
            doctor_id=request.form['doctor_id'],
            appointment_date=appointment_date,
            reason=request.form.get('reason'),
            duration=request.form.get('duration', 30)
        )
        
        db.session.add(appointment)
        db.session.commit()
        
        flash('Запись на прием создана', 'success')
        return redirect(url_for('appointments_list'))
    
    patients = Patient.query.all()
    doctors = Doctor.query.all()
    return render_template('create_appointment.html', patients=patients, doctors=doctors)

@app.route('/appointment/<int:appointment_id>/update-status', methods=['POST'])
@login_required
@role_required([UserRole.DOCTOR, UserRole.ADMIN, UserRole.NURSE])
def update_appointment_status(appointment_id):
    appointment = Appointment.query.get_or_404(appointment_id)
    new_status = request.form.get('status')
    
    if new_status in ['scheduled', 'completed', 'cancelled', 'no_show']:
        appointment.status = new_status
        db.session.commit()
        flash('Статус приема обновлен', 'success')
    
    return redirect(url_for('appointments_list'))

@app.route('/doctor/schedule')
@login_required
@role_required([UserRole.DOCTOR])
def doctor_schedule():
    doctor = current_user.doctor_profile
    if not doctor:
        flash('Профиль врача не найден', 'error')
        return redirect(url_for('dashboard'))
    
    start_date = datetime.utcnow().date()
    end_date = start_date + timedelta(days=7)
    
    weekly_schedule = Appointment.query.filter_by(
        doctor_id=doctor.id
    ).filter(
        Appointment.appointment_date >= start_date,
        Appointment.appointment_date <= end_date
    ).order_by(Appointment.appointment_date).all()
    
    return render_template('doctor_schedule.html',
                         doctor=doctor,
                         weekly_schedule=weekly_schedule,
                         start_date=start_date,
                         end_date=end_date)

@app.route('/doctor/statistics')
@login_required
@role_required([UserRole.DOCTOR])
def doctor_statistics():
    doctor = current_user.doctor_profile
    if not doctor:
        flash('Профиль врача не найден', 'error')
        return redirect(url_for('dashboard'))
    
    diagnosis_stats = db.session.query(
        MedicalNote.diagnosis,
        db.func.count(MedicalNote.id)
    ).filter_by(doctor_id=doctor.id).group_by(MedicalNote.diagnosis).order_by(db.func.count(MedicalNote.id).desc()).limit(10).all()
    
    monthly_stats = db.session.query(
        db.func.strftime('%Y-%m', MedicalNote.visit_date),
        db.func.count(MedicalNote.id)
    ).filter_by(doctor_id=doctor.id).group_by(db.func.strftime('%Y-%m', MedicalNote.visit_date)).order_by(db.func.strftime('%Y-%m', MedicalNote.visit_date)).all()
    
    return render_template('doctor_statistics.html',
                         doctor=doctor,
                         diagnosis_stats=diagnosis_stats,
                         monthly_stats=monthly_stats)

@app.route('/reports')
@login_required
@role_required([UserRole.ADMIN, UserRole.DOCTOR])
def reports():
    return render_template('reports.html')

@app.route('/api/reports/patient-stats')
@login_required
@role_required([UserRole.ADMIN, UserRole.DOCTOR])
def api_patient_stats():
    total_patients = Patient.query.count()
    patients_with_records = MedicalRecord.query.count()
    patients_with_appointments = db.session.query(db.func.count(db.distinct(Appointment.patient_id))).scalar()
    
    return jsonify({
        'total_patients': total_patients,
        'patients_with_records': patients_with_records,
        'patients_with_appointments': patients_with_appointments
    })

@app.route('/api/reports/appointment-stats')
@login_required
@role_required([UserRole.ADMIN, UserRole.DOCTOR])
def api_appointment_stats():
    today = date.today()
    week_ago = today - timedelta(days=7)
    month_ago = today - timedelta(days=30)
    
    today_count = Appointment.query.filter(db.func.date(Appointment.appointment_date) == today).count()
    week_count = Appointment.query.filter(Appointment.appointment_date >= week_ago).count()
    month_count = Appointment.query.filter(Appointment.appointment_date >= month_ago).count()
    
    return jsonify({
        'today': today_count,
        'week': week_count,
        'month': month_count
    })

def create_test_data():
    if not User.query.first():
        print("🔄 Создаем тестовых пользователей...")
        
        admin = User(
            username='admin',
            email='admin@hospital.ru',
            password=generate_password_hash('admin123'),
            role=UserRole.ADMIN
        )
        db.session.add(admin)
        db.session.commit()
        
        doctor_user = User(
            username='doctor',
            email='doctor@hospital.ru',
            password=generate_password_hash('doctor123'),
            role=UserRole.DOCTOR
        )
        db.session.add(doctor_user)
        db.session.commit()
        
        doctor_profile = Doctor(
            user_id=doctor_user.id,
            full_name='Иванов Александр Сергеевич',
            specialization='Терапевт',
            license_number='DOC-001',
            department='Терапевтическое отделение',
            office_number='101',
            phone='+7-999-123-4567'
        )
        db.session.add(doctor_profile)
        db.session.commit()
        
        nurse_user = User(
            username='nurse', 
            email='nurse@hospital.ru',
            password=generate_password_hash('nurse123'),
            role=UserRole.NURSE
        )
        db.session.add(nurse_user)
        db.session.commit()
        
        patient_user = User(
            username='patient',
            email='patient@hospital.ru',
            password=generate_password_hash('patient123'),
            role=UserRole.PATIENT
        )
        db.session.add(patient_user)
        db.session.commit()
        
        patient_profile = Patient(
            user_id=patient_user.id,
            full_name='Петров Иван Васильевич',
            birth_date=date(1985, 5, 15),
            phone='+7-999-765-4321',
            email='patient@hospital.ru',
            address='г. Москва, ул. Примерная, д. 1',
            insurance_number='INS-123456'
        )
        db.session.add(patient_profile)
        db.session.commit()
        
        medical_record = MedicalRecord(
            patient_id=patient_profile.id,
            blood_type='II+',
            allergies='Пенициллин, цитрусовые',
            chronic_diseases='Гипертония',
            current_medications='Эналаприл 5мг 1 раз в день'
        )
        db.session.add(medical_record)
        db.session.commit()
        
        test_document = Document(
            patient_id=patient_profile.id,
            record_id=medical_record.id,
            filename='test_document.pdf',
            original_filename='пример_документа.pdf',
            file_path='uploads/test_document.pdf',
            file_type='pdf',
            file_size=1024,
            description='Пример загруженного документа',
            uploaded_by=admin.id
        )
        db.session.add(test_document)
        db.session.commit()
        
        print("🎉 Тестовые данные успешно созданы!")
        print("👨‍💼 Админ: admin / admin123")
        print("👨‍⚕️ Врач: doctor / doctor123") 
        print("👩‍⚕️ Медсестра: nurse / nurse123")
        print("👤 Пациент: patient / patient123")
        print("📎 Тестовый документ добавлен в медкарту")

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        create_test_data()
    app.run(debug=True)